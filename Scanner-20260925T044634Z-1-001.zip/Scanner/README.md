



## Integrantes

- Yadira Eulalia Baca Torres
- Kerly Genesis Baño Pibaque
- Solange Johanna Burgos Burgos
- Mayra Elizabeth Enríquez León
- Lorena Katherine Flores Cabrera
- Pedro Antonio Roca Álvarez
- Denisse Dayana Zambrano Morales

## Funcionalidades

1. Ingresar una dirección IP (valida formato IPv4 o resuelve un nombre de host).
2. Ingresar un puerto inicial (1–65535).
3. Ingresar un puerto final (mayor o igual al inicial).
4. Realizar el escaneo concurrente (100 hilos, tiempo de espera de 0,5 s por puerto).
5. Mostrar los puertos abiertos con el nombre de su servicio estándar (IANA).
6. Mostrar un resumen: puertos analizados, abiertos, cerrados/filtrados y tiempo total.

## Herramientas

- Python 3.8 o superior (solo biblioteca estándar: `socket`, `ipaddress`, `concurrent.futures`, `argparse`)
- Visual Studio Code
- Git y GitHub

```bash
python scanner_puertos.py -i 127.0.0.1 -d 1 -h 1024
```

## Ejemplo de salida

```
==================================================
               ESCÁNER DE PUERTOS
==================================================
IP: 127.0.0.1
Desde: 1
Hasta: 100
Escaneando...
Puerto 22 - ABIERTO (ssh)
Puerto 80 - ABIERTO (http)
--------------------------------------------------
RESUMEN
Puertos analizados: 100
Puertos abiertos: 2
Puertos cerrados/filtrados: 98
Tiempo total: 0.02 segundos
==================================================
```

## Estructura del repositorio

```
scanner-puertos-python/
├── scanner_puertos.py   # Código fuente de la aplicación
├── README.md            # Descripción general del proyecto
├── MANUAL_USO.md        # Manual de uso paso a paso
└── capturas/            # Capturas de pantalla del funcionamiento
```

## Aviso de uso ético y legal

Esta herramienta tiene fines exclusivamente educativos. Úsela **solo** sobre su propio equipo, máquinas virtuales o laboratorios en los que tenga autorización expresa. El escaneo de sistemas ajenos sin permiso puede constituir un delito informático (en Ecuador, véase el art. 234 del Código Orgánico Integral Penal sobre acceso no consentido a un sistema informático).

## Referencias

- Lyon, G. F. (2009). *Nmap network scanning: The official Nmap project guide to network discovery and security scanning*. Insecure.Com LLC.
- Python Software Foundation. (2024). *socket — Low-level networking interface*. https://docs.python.org/3/library/socket.html
- Eddy, W. (Ed.). (2022). *Transmission Control Protocol (TCP)* (RFC 9293). IETF. https://doi.org/10.17487/RFC9293
