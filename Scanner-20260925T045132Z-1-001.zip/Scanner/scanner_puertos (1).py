#!/usr/bin/env python3
# -*- coding: utf-8 -*-


import argparse
import ipaddress
import socket
import sys
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime

# ----------------------------------------------------------------------------
# Parámetros generales
# ----------------------------------------------------------------------------
PUERTO_MIN = 1          # Puerto TCP válido más bajo
PUERTO_MAX = 65535      # Puerto TCP válido más alto (16 bits)
TIEMPO_ESPERA = 0.5     # Segundos que se espera la respuesta de cada puerto
HILOS = 100             # Número de conexiones simultáneas


def mostrar_encabezado():
    """Imprime el título de la aplicación y el aviso de uso ético."""
    print("=" * 50)
    print("               ESCÁNER DE PUERTOS")
    print("=" * 50)
    print(" Uso exclusivo en equipos propios, máquinas")
    print(" virtuales o laboratorios autorizados.")
    print("-" * 50)


def validar_ip(texto):
    """
    Comprueba que el texto sea una dirección IPv4 válida.
    También acepta un nombre de host (por ejemplo, 'localhost') y lo
    resuelve a IPv4. Devuelve la IP como cadena o None si no es válida.
    """
    texto = texto.strip()
    try:
        return str(ipaddress.IPv4Address(texto))
    except ipaddress.AddressValueError:
        try:
            return socket.gethostbyname(texto)
        except socket.gaierror:
            return None


def validar_puerto(texto):
    """Convierte el texto a entero y verifica que esté entre 1 y 65535."""
    try:
        puerto = int(texto)
    except (TypeError, ValueError):
        return None
    if PUERTO_MIN <= puerto <= PUERTO_MAX:
        return puerto
    return None


def pedir_ip():
    """Solicita la IP al usuario hasta que ingrese un valor válido."""
    while True:
        ip = validar_ip(input("IP: "))
        if ip:
            return ip
        print("  [!] Dirección IP no válida. Ejemplo: 192.168.1.10")


def pedir_puerto(mensaje, minimo=PUERTO_MIN):
    """Solicita un puerto al usuario y verifica que sea >= minimo."""
    while True:
        puerto = validar_puerto(input(mensaje))
        if puerto is not None and puerto >= minimo:
            return puerto
        print(f"  [!] Ingrese un número entre {minimo} y {PUERTO_MAX}.")


def nombre_servicio(puerto):
    """Devuelve el nombre del servicio estándar asociado al puerto (IANA)."""
    try:
        return socket.getservbyport(puerto, "tcp")
    except OSError:
        return "desconocido"


def escanear_puerto(ip, puerto, tiempo_espera=TIEMPO_ESPERA):
    """
    Intenta establecer una conexión TCP completa con ip:puerto.
    connect_ex() devuelve 0 si el saludo de tres vías (SYN, SYN-ACK, ACK)
    se completa, lo que indica que el puerto está ABIERTO.
    Devuelve una tupla (puerto, abierto: bool).
    """
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.settimeout(tiempo_espera)
        try:
            resultado = s.connect_ex((ip, puerto))
        except OSError:
            resultado = 1
    return puerto, resultado == 0


def escanear_rango(ip, inicio, fin, hilos=HILOS, tiempo_espera=TIEMPO_ESPERA):
    """
    Escanea todos los puertos entre inicio y fin (inclusive) usando un
    grupo de hilos para acelerar el proceso. Devuelve la lista ordenada
    de puertos abiertos.
    """
    abiertos = []
    with ThreadPoolExecutor(max_workers=hilos) as ejecutor:
        tareas = [ejecutor.submit(escanear_puerto, ip, p, tiempo_espera)
                  for p in range(inicio, fin + 1)]
        for tarea in as_completed(tareas):
            puerto, abierto = tarea.result()
            if abierto:
                abiertos.append(puerto)
    return sorted(abiertos)


def mostrar_resultados(abiertos, total, duracion):
    """Muestra los puertos abiertos y el resumen final del escaneo."""
    for puerto in abiertos:
        print(f"Puerto {puerto} - ABIERTO ({nombre_servicio(puerto)})")
    if not abiertos:
        print("No se encontraron puertos abiertos en el rango indicado.")
    print("-" * 50)
    print("RESUMEN")
    print(f"Puertos analizados: {total}")
    print(f"Puertos abiertos: {len(abiertos)}")
    print(f"Puertos cerrados/filtrados: {total - len(abiertos)}")
    print(f"Tiempo total: {duracion:.2f} segundos")
    print("=" * 50)


def leer_argumentos():
    """Permite ejecutar el programa también con argumentos opcionales."""
    parser = argparse.ArgumentParser(
        description="Escáner de puertos TCP (uso académico y autorizado).",
        add_help=False)
    parser.add_argument("-i", "--ip", help="Dirección IP objetivo")
    parser.add_argument("-d", "--desde", help="Puerto inicial")
    parser.add_argument("-h", "--hasta", help="Puerto final")
    parser.add_argument("--ayuda", action="help",
                        help="Muestra esta ayuda y termina")
    return parser.parse_args()


def main():
    args = leer_argumentos()
    mostrar_encabezado()

    # 1. Ingresar una dirección IP
    if args.ip and validar_ip(args.ip):
        ip = validar_ip(args.ip)
        print(f"IP: {ip}")
    else:
        ip = pedir_ip()

    # 2. Ingresar un puerto inicial
    inicio = validar_puerto(args.desde) if args.desde else None
    if inicio is None:
        inicio = pedir_puerto("Desde: ")
    else:
        print(f"Desde: {inicio}")

    # 3. Ingresar un puerto final (debe ser mayor o igual al inicial)
    fin = validar_puerto(args.hasta) if args.hasta else None
    if fin is None or fin < inicio:
        fin = pedir_puerto("Hasta: ", minimo=inicio)
    else:
        print(f"Hasta: {fin}")

    # 4. Realizar el escaneo
    total = fin - inicio + 1
    print(f"Inicio: {datetime.now():%Y-%m-%d %H:%M:%S}")
    print("Escaneando...")
    t0 = time.perf_counter()
    abiertos = escanear_rango(ip, inicio, fin)
    duracion = time.perf_counter() - t0

    # 5 y 6. Mostrar puertos abiertos y resumen
    mostrar_resultados(abiertos, total, duracion)


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n[!] Escaneo cancelado por el usuario.")
        sys.exit(1)
