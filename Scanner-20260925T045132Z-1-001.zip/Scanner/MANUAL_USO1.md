# Manual de uso — Escáner de Puertos TCP

Este manual explica, de forma sencilla, cómo instalar, ejecutar e interpretar los resultados de `scanner_puertos.py`.

> **Importante:** escanee únicamente su propio equipo, una máquina virtual o un laboratorio autorizado.

---

## 1. Requisitos para ejecutar el programa

| Requisito | Detalle |
|---|---|
| Sistema operativo | Windows 10/11, Linux o macOS |
| Python | Versión 3.8 o superior (probado con 3.11) |
| Bibliotecas | Ninguna externa: solo la biblioteca estándar (`socket`, `ipaddress`, `concurrent.futures`, `argparse`) |
| Editor (opcional) | Visual Studio Code con la extensión *Python* |
| Git (opcional) | Para clonar el repositorio desde GitHub |
| Permisos | Autorización sobre el equipo que se va a escanear |

Para comprobar la versión de Python:

```bash
python --version      # Windows
python3 --version     # Linux / macOS
```

![Requisitos](capturas/01_requisitos.png)

## 2. Instalación

**Opción A — con Git:**

```bash
git clone https://github.com/jpalmas3-dot/Scanner.git
cd scanner-puertos-python
```

**Opción B — sin Git:** en la página del repositorio pulse **Code → Download ZIP**, descomprima el archivo y abra la carpeta `scanner-puertos-python`.

No se necesita `pip install`, porque el programa solo usa módulos incluidos en Python.

## 3. Cómo iniciar la aplicación

1. Abra una terminal (en VS Code: **Terminal → New Terminal**).
2. Ubíquese en la carpeta del proyecto.
3. Ejecute:

```bash
python scanner_puertos.py        # Windows
python3 scanner_puertos.py       # Linux / macOS
```

Aparecerá el encabezado **ESCÁNER DE PUERTOS** y el aviso de uso ético. Para ver las opciones disponibles:

```bash
python scanner_puertos.py --ayuda
```

![Ayuda](capturas/03_ayuda.png)

## 4. Cómo ingresar la IP

Cuando aparezca `IP:` escriba la dirección del equipo autorizado y pulse **Enter**.

- Su propio equipo: `127.0.0.1` (o `localhost`).
- Una máquina virtual o un equipo de su red: la IP que muestre `ipconfig` (Windows) o `hostname -I` / `ip a` (Linux), por ejemplo `192.168.1.10`.

Si la IP no es válida (por ejemplo `192.168.1.300`), el programa muestra `[!] Dirección IP no válida` y la vuelve a pedir.

![IP utilizada](capturas/02_ip_utilizada.png)

## 5. Cómo seleccionar el rango de puertos

- En `Desde:` escriba el puerto inicial (mínimo **1**).
- En `Hasta:` escriba el puerto final (máximo **65535** y no menor que el inicial).

Rangos recomendados:

| Rango | Uso |
|---|---|
| 1 – 100 | Prueba rápida (ejemplo de la guía) |
| 1 – 1024 | Puertos bien conocidos (*well-known ports*) |
| 1 – 10000 | Revisión más amplia de servicios comunes |
| 1 – 65535 | Todos los puertos TCP (tarda más) |

Si el valor es inválido se muestra `[!] Ingrese un número entre 1 y 65535.`

![Validaciones](capturas/05_escaneo_validaciones_1_1024.png)

## 6. Cómo ejecutar el escaneo

Después de ingresar el puerto final, el escaneo empieza automáticamente y aparece `Escaneando...`. El programa prueba 100 puertos a la vez con un tiempo de espera de 0,5 segundos por puerto.

También puede ejecutarlo en una sola línea:

```bash
python scanner_puertos.py -i 127.0.0.1 -d 1 -h 10000
```

Para cancelar un escaneo en curso pulse **Ctrl + C**.

![Escaneo 1-100](capturas/04_escaneo_1_100.png)

## 7. Cómo interpretar los resultados

| Mensaje | Significado |
|---|---|
| `Puerto 22 - ABIERTO (ssh)` | El puerto aceptó la conexión TCP: hay un servicio escuchando. Entre paréntesis se indica el servicio estándar según IANA. |
| `(desconocido)` | El puerto está abierto pero no tiene un servicio estándar registrado. |
| `Puertos analizados` | Cantidad total de puertos del rango. |
| `Puertos abiertos` | Cantidad de puertos que respondieron. |
| `Puertos cerrados/filtrados` | Puertos que rechazaron la conexión o no respondieron (posible cortafuegos). |
| `Tiempo total` | Duración del escaneo en segundos. |

Recomendación: cada puerto abierto es un posible punto de entrada. Si un servicio no se utiliza, ciérrelo o bloquéelo con el cortafuegos.

![Escaneo 1-10000](capturas/06_escaneo_1_10000.png)

## 8. Problemas frecuentes

| Problema | Solución |
|---|---|
| `python no se reconoce como un comando` | Instale Python y marque *Add Python to PATH*, o use `py scanner_puertos.py`. |
| Todos los puertos salen cerrados | Verifique la IP, que el equipo esté encendido y que el cortafuegos permita conexiones. |
| El escaneo es lento | Reduzca el rango de puertos o escanee un equipo de la red local. |
